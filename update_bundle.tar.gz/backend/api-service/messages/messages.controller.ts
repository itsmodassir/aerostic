import { Body, Controller, Post, Get, Param, Query, UseGuards, Req, UseInterceptors, UploadedFile } from "@nestjs/common";
import { FileInterceptor } from "@nestjs/platform-express";
import { MessagesService } from "./messages.service";
import { SendMessageDto } from "./dto/send-message.dto";
import { JwtAuthGuard } from "@api/auth/jwt-auth.guard";
import { UserTenant } from "../auth/decorators/user-tenant.decorator";
import { WhatsappService } from "@shared/whatsapp/whatsapp.service";

@Controller("messages")
@UseGuards(JwtAuthGuard)
export class MessagesController {
  constructor(
    private readonly messagesService: MessagesService,
    private readonly whatsappService: WhatsappService,
  ) { }

  @Post("upload")
  @UseInterceptors(FileInterceptor("file"))
  async uploadFile(
    @UserTenant() tenantId: string,
    @UploadedFile() file: any,
  ) {
    return this.whatsappService.uploadMedia(
      tenantId,
      file.buffer,
      file.originalname,
      file.mimetype,
    );
  }

  @Post("send")
  async sendMessage(
    @UserTenant() tenantId: string,
    @Body() dto: SendMessageDto,
    @Req() req: any,
  ) {
    dto.tenantId = tenantId;
    // Attach the authenticated user's ID as agentId when sending from dashboard
    // This triggers the AI handover auto-pause if enabled
    if (!dto.agentId && req.user?.id) {
      dto.agentId = req.user.id;
    }
    return this.messagesService.send(dto);
  }

  @Get("recent")
  async getRecentMessages(@UserTenant() tenantId: string, @Query("limit") limit?: string) {
    return this.messagesService.getRecentMessages(tenantId, parseInt(limit || '5', 10));
  }

  @Get("conversations")
  async getConversations(@UserTenant() tenantId: string) {
    return this.messagesService.getConversations(tenantId);
  }

  @Get("conversations/:id")
  async getConversationMessages(
    @UserTenant() tenantId: string,
    @Param("id") conversationId: string,
  ) {
    return this.messagesService.getMessages(tenantId, conversationId);
  }

  /** Get AI mode status + 24h window timer for a conversation */
  @Get("conversations/:id/status")
  async getConversationStatus(
    @UserTenant() tenantId: string,
    @Param("id") conversationId: string,
  ) {
    return this.messagesService.getConversationStatus(conversationId, tenantId);
  }

  /** Set AI mode: toggle between 'ai', 'human', or 'paused' */
  @Post("conversations/:id/ai-mode")
  async setAiMode(
    @UserTenant() tenantId: string,
    @Param("id") conversationId: string,
    @Body() body: { mode: 'ai' | 'human' | 'paused'; pauseMinutes?: number },
  ) {
    return this.messagesService.setAiMode(
      conversationId,
      tenantId,
      body.mode,
      body.pauseMinutes,
    );
  }
}
