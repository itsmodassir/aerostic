import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from "typeorm";
import { Tenant } from "./tenant.entity";
import { User } from "./user.entity";

export enum ContactStatus {
  NEW = "NEW",
  CONTACTED = "CONTACTED",
  QUALIFIED = "QUALIFIED",
  PROPOSAL = "PROPOSAL",
  WON = "WON",
  LOST = "LOST",
}

@Entity("contacts")
@Index(["tenantId", "phoneNumber"], { unique: true })
export class Contact {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ name: "tenant_id", type: "uuid" })
  @Index()
  tenantId: string;

  @ManyToOne(() => Tenant, { onDelete: "CASCADE" })
  @JoinColumn({ name: "tenant_id" })
  tenant: Tenant;

  @Column({ name: "phone_number" })
  @Index()
  phoneNumber: string;

  @Column()
  name: string;

  @Column({ nullable: true })
  email: string;

  @Column({
    type: "enum",
    enum: ContactStatus,
    default: ContactStatus.NEW,
  })
  @Index()
  status: ContactStatus;

  @Column({ type: "int", default: 0 })
  score: number;

  @Column({ name: "assigned_to", nullable: true, type: "uuid" })
  assignedToId: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: "assigned_to" })
  assignedTo: User;

  @Column({ name: "is_vip", default: false })
  isVIP: boolean;

  @Column({ type: "jsonb", nullable: true, default: [] })
  groups: string[];

  @Column({ type: "jsonb", default: {} })
  attributes: Record<string, any>;

  @CreateDateColumn({ name: "created_at" })
  createdAt: Date;

  @UpdateDateColumn({ name: "updated_at" })
  updatedAt: Date;
}
